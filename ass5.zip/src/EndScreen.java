import biuoop.KeyboardSensor;
import biuoop.DrawSurface;
import biuoop.Sleeper;

import java.awt.Color;
import java.util.Random;

/**
 * The End screen.
 */
public class EndScreen implements Animation {
    private int score;
    private int numOfBallsRemained;
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param score              score of the game
     * @param numOfBallsRemained number of remained balls in the game
     * @param k                  keyboard
     */
    public EndScreen(int score, int numOfBallsRemained, KeyboardSensor k) {
        this.score = score;
        this.numOfBallsRemained = numOfBallsRemained;
        this.keyboard = k;
        this.stop = false;
    }

    /**
     * In charge of the logic.
     *
     * @param d surface
     */
    public void doOneFrame(DrawSurface d) {
        if (numOfBallsRemained == 0) { // lost
            d.setColor(Color.decode("#000080"));
            d.fillRectangle(0, 0, d.getWidth(), d.getHeight());
            d.setColor(Color.WHITE);
            d.drawText(228, d.getHeight() / 3 + 50, "GAME OVER", 56);
            d.drawText(306, d.getHeight() - 100, "Your Score Is " + String.valueOf(this.score), 26);
            d.setColor(Color.YELLOW);
            // smiley face
            d.setColor(Color.YELLOW);
            d.fillCircle(d.getWidth() / 2, d.getHeight() - 235, 70); // head
            d.setColor(Color.BLACK);
            d.fillOval(d.getWidth() / 2 + 14, d.getHeight() - 266, 25, 38); // right eye
            d.fillOval(d.getWidth() / 2 - 36, d.getHeight() - 266, 25, 38); // left eye
            d.fillOval(d.getWidth() / 2 - 33, d.getHeight() - 212, 66, 30); // mouth
            d.setColor(Color.YELLOW);
            d.fillOval(d.getWidth() / 2 - 33, d.getHeight() - 202, 66, 31); // sad mouth

        } else { // win
            d.setColor(Color.decode("#FF00FF"));
            d.fillRectangle(0, 0, d.getWidth(), d.getHeight());
            Random rand = new Random();
            Sleeper sleeper = new Sleeper();
            for (int i = 1; i <= 60; i++) {
                int x = rand.nextInt(800) + 1;
                int y = rand.nextInt(600) + 1;
                Color color = new AnimationParameters().randomColor();
                d.setColor(color);
                d.fillCircle(x, y, 7);
                sleeper.sleepFor(3);
            }
            d.setColor(Color.WHITE);
            d.drawText(140, d.getHeight() / 3 + 50, "YOU WIN THE GAME!", 50);
            d.drawText(300, d.getHeight() / 2 + 30, "Your Score Is " + String.valueOf(this.score), 26);
        }

        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.stop = true;
        }
    }

    /**
     * is in charge of stopping condition.
     *
     * @return true or false
     */
    public boolean shouldStop() {
        return this.stop;
    }
}


