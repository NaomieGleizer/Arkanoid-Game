import biuoop.DrawSurface;

/**
 * Animation interface.
 */
public interface Animation {
    /**
     * is in charge of the logic.
     *
     * @param d surface
     */
    void doOneFrame(DrawSurface d);

    /**
     * is in charge of stopping condition.
     *
     * @return true or false
     */
    boolean shouldStop();
}