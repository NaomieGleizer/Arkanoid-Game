
/**
 * The Collidable interface is used by things that can be collided with.
 */
interface Collidable {
    /**
     * @return the "collision shape" of the object.
     */
    Rectangle getCollisionRectangle();

    /**
     * @param hitter the ball
     * @param collisionPoint  the location of the object
     * @param currentVelocity the velocity of the object
     * @return is the new velocity expected after the hit
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}