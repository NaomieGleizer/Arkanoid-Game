import biuoop.KeyboardSensor;

import java.util.List;

/**
 * The game runner.
 */
public class GameFlow {
    private AnimationRunner runner;
    private KeyboardSensor keyboard;
    private int frameWidth;
    private int frameHeight;

    /**
     * Constructor.
     *
     * @param ar          animation runner
     * @param ks          keyboard
     * @param frameWidth  the width of the screen
     * @param frameHeight the height of the screen
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, int frameWidth, int frameHeight) {
        this.runner = ar;
        ar.setFramesPerSecond(60);
        this.keyboard = ks;
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
    }

    /**
     * run every level of the game.
     *
     * @param levels levels of the game
     */
    public void runLevels(List<LevelInformation> levels) {
        int score = 0, remainedBalls = 0;
        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo, this.runner, this.keyboard, this.frameWidth, this.frameHeight);
            level.initialize();

            // run every level until it's over(lose or win)
            while (level.getNumOfLife() != 0 && level.getNumOfRemainedBlocks() != 0) {
                level.getNumOfRemainedBall().increase(levelInfo.numberOfBalls());
                level.playOneTurn();
            }
            score = level.getScore();
            remainedBalls = level.getNumOfRemainedBall().getValue();
            if (level.getNumOfLife() == 0) {
                break;
            }
        }
        // end screen- win or lose
        this.runner.run(new EndScreen(score, remainedBalls, this.keyboard));
        this.runner.getGui().close();
    }
}
