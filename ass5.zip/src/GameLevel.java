import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

import java.util.List;
import java.awt.Color;

/**
 * The game.
 */
public class GameLevel implements Animation {
    public static final int BORDERS_BLOCKS_SIZE = 25;
    public static final int BLOCKS_HEIGHT = 30;
    public static final double SCORE_BLOCK_HEIGHT = 24;
    public static final int PADDLE_HEIGHT = 25;


    private int frameHeight;
    private int frameWidth;
    private SpriteCollection sprites = new SpriteCollection();
    private GameEnvironment environment = new GameEnvironment();
    private Counter remainedBlocks = new Counter(0);
    private Counter remainedBalls = new Counter(0);
    private static Counter score = new Counter(0);
    private static Counter numOfLives = new Counter(7);
    private AnimationRunner runner;
    private boolean running = this.remainedBlocks.getValue() > 0 && this.remainedBalls.getValue() > 0;
    private KeyboardSensor keyboard;
    private LevelInformation level;
    private Paddle paddle;

    /**
     * Constructor.
     *
     * @param levelInformation level of the game
     * @param ar               animation runner
     * @param keyboard         keyboard
     * @param width            width of the screen
     * @param height           height of the screen
     */
    public GameLevel(LevelInformation levelInformation, AnimationRunner ar, KeyboardSensor keyboard, int width
            , int height) {
        this.level = levelInformation;
        this.frameWidth = width;
        this.frameHeight = height;
        this.keyboard = keyboard;
        this.runner = ar;
    }

    /**
     * @param c a collidable to add
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * @param s a sprite to add
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Initialize a new game: create the Blocks, balls and Paddle, and add them to the game.
     */
    public void initialize() {
        BlockRemover blockRemover = new BlockRemover(this, this.remainedBlocks);
        BallRemover ballRemover = new BallRemover(this, this.remainedBalls);
        ScoreTrackingListener scoreTrackingListener = new ScoreTrackingListener(this.score);
        // Add the background of the level as a sprite to the game
        Sprite backGround = this.level.getBackground();
        backGround.addToTheGame(this);
        // create the lives block;
        this.createLivesBlock();
        // create score block
        this.createScoreBlock();
        // create blocks at the borders
        this.createBlocksAtTheBorders();
        // Create a special block that will sit at the bottom of the screen, and will function as a "death region"
        Block killBlock = this.createBottomKillBlock();
        killBlock.addHitListener(ballRemover);

        // creates the blocks
        List<Block> blocks = this.level.blocks();
        this.remainedBlocks.increase(this.level.numberOfBlocksToRemove());
        for (Block block : blocks) {
            block.addToTheGame(this);
            block.addHitListener(blockRemover);
            block.addHitListener(scoreTrackingListener);
        }
    }

    /**
     * Create the balls  and the paddle for the game.
     */
    public void createBallsAndPaddle() {
        // create paddle
        Point upperLeftPaddle = new Point((this.frameWidth - this.level.paddleWidth()) / 2, this.frameHeight - 25);
        Rectangle paddleRect = new Rectangle(upperLeftPaddle, this.level.paddleWidth(), PADDLE_HEIGHT);
        paddleRect.setColor(Color.decode("#FFD700"));
        this.paddle = new Paddle(this.keyboard, BORDERS_BLOCKS_SIZE, this.frameWidth - BORDERS_BLOCKS_SIZE
                , this.level.paddleSpeed());
        this.paddle.setShape(paddleRect);
        this.paddle.addToTheGame(this);

        // create the balls
        int numOfBalls = this.level.numberOfBalls();
        Ball[] balls = new Ball[numOfBalls];
        List<Velocity> velocities = this.level.initialBallVelocities();
        for (int i = 0; i < numOfBalls; i++) {
            int centerX = this.frameWidth / 2;
            Point center = new Point(centerX, this.frameHeight - 32);
            balls[i] = new Ball(center, 8, Color.WHITE);
            balls[i].setVelocity(velocities.get(i));
            // add the ball to the game
            balls[i].addToTheGame(this);
            balls[i].setGameEnvironment(this.environment);
        }
    }

    /**
     * Play one life.
     */
    public void playOneTurn() {
        this.createBallsAndPaddle();
        this.runner.setFramesPerSecond(2); // frames for the countdown
        this.runner.run(new CountdownAnimation(2, 3, this.sprites));
        this.runner.setFramesPerSecond(60); // frames for the game
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);

        if (remainedBlocks.getValue() == 0) {
            score.increase(100);
        } else {
            this.numOfLives.decrease(1);
        }
        this.removeSprite(this.paddle);
        this.removeCollidable(this.paddle);
    }

    /**
     * Remove the Collidable from the game.
     *
     * @param c Collidable
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);

    }

    /**
     * Remove the sprite from the game.
     *
     * @param s sprite
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    /**
     * Crates the blocks at the borders.
     */
    public void createBlocksAtTheBorders() {
        Rectangle r1 = new Rectangle(new Point(0, SCORE_BLOCK_HEIGHT), BORDERS_BLOCKS_SIZE
                , this.frameHeight - SCORE_BLOCK_HEIGHT); // left
        r1.setColor(Color.GRAY);
        Rectangle r2 = new Rectangle(new Point(0, SCORE_BLOCK_HEIGHT), this.frameWidth, BORDERS_BLOCKS_SIZE);  // top
        r2.setColor(Color.GRAY);
        Rectangle r4 = new Rectangle(new Point(this.frameWidth - BORDERS_BLOCKS_SIZE, SCORE_BLOCK_HEIGHT)      // right
                , BORDERS_BLOCKS_SIZE, this.frameHeight - SCORE_BLOCK_HEIGHT);
        r4.setColor(Color.GRAY);

        // add them to the game
        Block top = new Block(r1, 0);
        top.addToTheGame(this);
        Block left = new Block(r2, 0);
        left.addToTheGame(this);
        Block right = new Block(r4, 0);
        right.addToTheGame(this);
    }

    /**
     * @return the block which is located below the screen and is responsible for the lost of the balls.
     */
    public Block createBottomKillBlock() {
        Block bottomBlock = new Block(new Rectangle(new Point(0, this.frameHeight), this.frameWidth, BLOCKS_HEIGHT), 0);
        bottomBlock.getCollisionRectangle().setColor(Color.BLACK);
        bottomBlock.addToTheGame(this);
        return bottomBlock;
    }

    /**
     * create the block for the score at top of the screen.
     */
    public void createScoreBlock() {
        ScoreIndicator scoreIndicator = new ScoreIndicator(new Rectangle(new Point(150, 0), this.frameWidth - 400
                , SCORE_BLOCK_HEIGHT), this.score);
        scoreIndicator.getShape().setColor(Color.CYAN);
        scoreIndicator.addToTheGame(this);
    }

    /**
     * create the block for the lives-indicator at top of the screen.
     */
    public void createLivesBlock() {
        LivesIndicator livesIndicator = new LivesIndicator(new Rectangle(new Point(0, 0), 150
                , SCORE_BLOCK_HEIGHT), this.remainedBalls, this.numOfLives);
        livesIndicator.getShape().setColor(Color.PINK);
        livesIndicator.addToTheGame(this);
    }

    /**
     * is in charge of the logic.
     *
     * @param d surface
     */
    public void doOneFrame(DrawSurface d) {
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();
        if (!(this.remainedBlocks.getValue() > 0 && this.remainedBalls.getValue() > 0)) {
            this.running = false;
        }
        if (this.keyboard.isPressed("p")) {
            this.runner.run(new PauseScreen(this.keyboard));
        }
    }

    /**
     * is in charge of stopping condition.
     *
     * @return true or false
     */
    public boolean shouldStop() {
        return !this.running;
    }

    /**
     * @return the number of life
     */
    public int getNumOfLife() {
        return this.numOfLives.getValue();
    }

    /**
     * @return the number of remaining blocks
     */
    public int getNumOfRemainedBlocks() {
        return this.remainedBlocks.getValue();
    }

    /**
     * @return the number of remaining balls
     */
    public Counter getNumOfRemainedBall() {
        return this.remainedBalls;
    }

    /**
     * @return the current score
     */
    public int getScore() {
        return this.score.getValue();
    }

}